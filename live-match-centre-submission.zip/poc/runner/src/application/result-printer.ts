import type { AggregatedMetrics, VerdictResult } from "../domain/result.js"
import { runTopologyPreflight, type TopologyPreflight } from "../adapters/topology-preflight.js"
import { resolveRuntimeContainerLimits } from "../adapters/runtime-container-limits.js"
import { ACTIVE_CONTRACT_VERSION } from "../domain/active-contract.js"

export function printSummary(
  metrics: AggregatedMetrics,
  eventsPublished: number,
  verdictResult: VerdictResult,
): void {
  metrics.events_published = eventsPublished

  console.log("")
  console.log("═══════════════════════════════════════════════════════════════")
  console.log("                    POC RESULTS SUMMARY                       ")
  console.log("═══════════════════════════════════════════════════════════════")
  console.log("")

  console.log("CONNECTIONS")
  console.log(`  Attempted:         ${metrics.connections_attempted}`)
  console.log(`  Established:       ${metrics.connections_established}`)
  console.log(`  Failures:          ${metrics.connection_failures}`)
  console.log(`  Target:            ${metrics.connections_target}`)
  console.log("")

  console.log("EVENTS")
  console.log(`  Published:         ${metrics.events_published}`)
  console.log(`  Received:          ${metrics.events_received}`)
  console.log(`  Missing seqs:      ${metrics.missing_sequences}`)
  console.log(`  Duplicates:        ${metrics.duplicates}`)
  console.log(`  Out of order:      ${metrics.out_of_order}`)
  console.log("")

  console.log("FAN-DELIVERY ACCOUNTING")
  console.log(`  Expected:          ${metrics.expected_fan_deliveries}`)
  console.log(`  Received:          ${metrics.received_fan_deliveries}`)
  const deliveryRatio = metrics.expected_fan_deliveries > 0
    ? ((metrics.received_fan_deliveries / metrics.expected_fan_deliveries) * 100).toFixed(2)
    : "N/A"
  console.log(`  Delivery ratio:    ${deliveryRatio}%`)
  console.log("")

  console.log("FAN-OUT LATENCY (publish -> SSE frame receipt)")
  console.log(`  p50:               ${metrics.fan_out_latency_p50_ms}ms`)
  console.log(`  p95:               ${metrics.fan_out_latency_p95_ms}ms`)
  console.log(`  p99:               ${metrics.fan_out_latency_p99_ms}ms`)
  console.log(`  max:               ${metrics.fan_out_latency_max_ms}ms`)
  console.log("")

  console.log("LATE-JOIN (connection open -> caught up)")
  console.log(`  p50:               ${metrics.late_join_p50_ms}ms`)
  console.log(`  p95:               ${metrics.late_join_p95_ms}ms`)
  console.log(`  p99:               ${metrics.late_join_p99_ms}ms`)
  console.log(`  max:               ${metrics.late_join_max_ms}ms`)
  console.log(`  [§BA: single-sample frozen interpretation — p95=p50=p99=max]`)
  console.log("")

  console.log("RECONNECT/RESUME")
  console.log(`  Gaps:              ${metrics.reconnect_gaps}`)
  console.log(`  Duplicates:        ${metrics.reconnect_duplicates}`)
  console.log(`  Order violations:  ${metrics.reconnect_order_violations}`)
  console.log("")

  console.log("SLOW CLIENT (§4.7)")
  const sc = metrics.slow_consumer_metrics
  if (sc) {
    console.log(`  Slow clients:      ${sc.slow_clients}/${sc.slow_clients + sc.healthy_clients}`)
    console.log(`  Slow offered:      ${sc.slow_offered_event_count} events`)
    console.log(`  Slow consumed:     ${sc.slow_application_read_count} events`)
    // §M3-HVR: offered vs consumed is expected to diverge under a deliberate
    // application-read gate; pacing proof is per-client inter-release timing,
    // and recovery evidence comes from the Last-Event-ID replay probe.
    console.log(`  Read rate:         ${sc.slow_achieved_read_rate_events_per_sec.toFixed(2)} events/s`)
    console.log(`  Median interval:   ${sc.slow_median_event_interval_ms.toFixed(0)}ms (target: 2000ms)`)
    if (sc.pacing_valid !== undefined) console.log(`  Pacing valid:      ${sc.pacing_valid}`)
    if (sc.replay_probe_clients !== undefined) {
      const selected = sc.replay_probe_selected ?? sc.replay_probe_clients
      const reattached = sc.replay_probe_reattached ?? selected
      console.log(`  Replay probe:      ${sc.replay_probe_replayed}/${sc.replay_probe_expected_missed} frames, selected=${selected} reattached=${reattached} — aggregate ${sc.replay_probe_coverage_pct !== null && sc.replay_probe_coverage_pct !== undefined ? `${sc.replay_probe_coverage_pct.toFixed(1)}%` : "unmeasurable"}, weakest client ${sc.replay_recovery_pct !== null && sc.replay_recovery_pct !== undefined ? `${sc.replay_recovery_pct.toFixed(1)}%` : "unmeasurable"}`)
      console.log(`  Catch-up drain:    ${sc.catchup_drained_count ?? 0} frames (backlog handoff, not replay)`)
    }
    console.log(`  Backlog growth:    ${sc.slow_backlog_growth} events`)
    console.log(`  Backpressure:      ${sc.evidence_server_side_backpressure_reached ? "YES" : "NO"}`)
    console.log(`  Healthy p95 before:${sc.healthy_p95_before_ms}ms`)
    console.log(`  Healthy p95 during:${sc.healthy_p95_during_slow_ms}ms`)
    console.log(`  Healthy degrade:   ${sc.healthy_degradation_pct.toFixed(1)}%`)
    console.log(`  Disconnects:       ${sc.slow_disconnects}`)
  } else {
    console.log(`  Disconnects:       ${metrics.slow_consumer_disconnects} (legacy)`)
  }
  console.log("")

  console.log("LOBBY")
  console.log(`  Subscribers:       ${metrics.lobby_subscribers}`)
  console.log("")

  console.log("RESOURCES")
  console.log(`  Event loop p99:    ${metrics.event_loop_delay_p99_ms}ms`)
  console.log(`  Memory peak:       ${metrics.memory_mb_peak}MB`)
  if (metrics.nchan_memory_mb_peak !== null) {
    console.log(`  Nchan memory peak: ${metrics.nchan_memory_mb_peak}MB`)
  } else {
    console.log(`  Nchan memory peak: unavailable (requires Docker socket)`)
  }
  if (metrics.redis_memory_mb_peak !== null) {
    console.log(`  Redis memory peak: ${metrics.redis_memory_mb_peak}MB`)
  } else {
    console.log(`  Redis memory peak: unavailable`)
  }
  console.log("")

  console.log("PUBLISHER (§BM)")
  console.log(`  Attempts:          ${metrics.publisher_attempts}`)
  console.log(`  Successes:         ${metrics.publisher_successes}`)
  console.log(`  Definite failures: ${metrics.publisher_definite_failures}`)
  console.log(`  Ambiguous:         ${metrics.publisher_ambiguous_failures}`)
  console.log(`  Backlog peak:      ${metrics.generator_backlog_peak}`)
  console.log("")

  console.log("PARSE ERRORS (§BJ)")
  console.log(`  SSE parse errors:  ${metrics.sse_parse_errors}`)
  console.log(`  JSON parse errors: ${metrics.json_parse_errors}`)
  console.log(`  Invalid timestamps:${metrics.invalid_timestamp_count}`)
  console.log("")

  console.log("SURGE HEALTH (§BH)")
  console.log(`  Events received:   ${metrics.surge_events_received}`)
  console.log(`  Missing sequences: ${metrics.surge_missing_sequences}`)
  console.log(`  Duplicates:        ${metrics.surge_duplicates}`)
  console.log(`  Out of order:      ${metrics.surge_out_of_order}`)
  console.log(`  Fan-out p95:       ${metrics.surge_fan_out_p95_ms}ms`)
  console.log("")

  if (metrics.phase_publish_rates.length > 0) {
    console.log("PHASE PUBLISH RATES")
    for (const pr of metrics.phase_publish_rates) {
      console.log(`  ${pr.phase.padEnd(12)} match=${(pr.matchEventsPerSec ?? 0).toFixed(1)} lobby=${(pr.lobbyEventsPerSec ?? 0).toFixed(1)} total=${(pr.totalEventsPerSec ?? pr.eventsPerSec).toFixed(1)} evt/s  hot-match: ${pr.hotMatchPct}%`)
    }
    console.log("")
  }

  console.log("═══════════════════════════════════════════════════════════════")

  for (const check of verdictResult.checks) {
    const status = check.passed ? "PASS" : "FAIL"
    console.log(`  ${status.padEnd(5)} ${check.name}: ${check.detail}`)
  }

  console.log("")
  console.log(`  VERDICT: ${verdictResult.verdict}`)
  console.log("═══════════════════════════════════════════════════════════════")
}

// §6.24: Machine-readable JSON result emitted to stdout after human summary
export function emitMachineReadableResult(
  metrics: AggregatedMetrics,
  eventsPublished: number,
  verdictResult: VerdictResult,
  config: { targetConnections: number; seed: number; runProfile: string; runMode?: string; warmupSeconds: number; measureSeconds: number; burstSeconds: number; surgeSeconds?: number; cooldownSeconds: number; slowConsumerFraction: number; lobbyFraction: number; nchanPubUrl?: string; nchanSubUrl?: string; redisUrl?: string; nchanControlUrl?: string },
  topologyPreflight?: TopologyPreflight,
  structuredScenarioEvidence?: Record<string, unknown>,
): void {
  metrics.events_published = eventsPublished

  // §4.2/§4.24: Run topology preflight if not provided
  const preflight = topologyPreflight ?? runTopologyPreflight(config.targetConnections)
  // §3.8/§4.18: Judge generator headroom against assigned CPU capacity,
  // not the raw multi-core process percentage (which may legitimately exceed 100%).
  const generatorHealthy = metrics.resource_cpu_percent_peak !== null
    && metrics.resource_cpu_percent_peak < 90
    && metrics.generator_event_loop_p99_ms < 100
    && metrics.generator_backlog_peak <= 1000

  const result = {
    contract_version: ACTIVE_CONTRACT_VERSION,
    aggregate_scope: config.runMode === "coordinated-shard" ? "shard" : "single_run",
    scope: config.runMode === "coordinated-shard" ? "shard" : "single_run",
    global_direct_accept_eligible: false,
    run_profile: config.runProfile,
    run_mode: config.runMode ?? "single",
    seed: config.seed,
    // §3.2: Shard identity in machine-readable output
    shard_identity: metrics.shard_identity,
    resolved_config: {
      target_connections: config.targetConnections,
      warmup_seconds: config.warmupSeconds,
      measure_seconds: config.measureSeconds,
      burst_seconds: config.burstSeconds,
      surge_seconds: config.surgeSeconds ?? 120,
      cooldown_seconds: config.cooldownSeconds,
      slow_consumer_fraction: config.slowConsumerFraction,
      lobby_fraction: config.lobbyFraction,
    },
    // §4.18: Environment and preflight
    environment: {
      node_version: process.version,
      platform: process.platform,
      arch: process.arch,
      pid: process.pid,
    },
    preflight: {
      nchan_pub_url: config.nchanPubUrl,
      nchan_sub_url: config.nchanSubUrl,
      redis_url: config.redisUrl,
      nchan_control_url: config.nchanControlUrl || null,
    },
    // §4.2/§4.24: Topology and capacity preflight
    host_limits: {
      fd_soft_limit: preflight.fd_soft_limit,
      fd_hard_limit: preflight.fd_hard_limit,
      ephemeral_port_range: preflight.ephemeral_port_range,
      ephemeral_port_count: preflight.ephemeral_port_count,
    },
    // §4.18: Runtime container resource limits — resolved from the actual
    // launched topology (runner: live /proc + self cgroup; DUT services:
    // launcher-provided env), never stale hard-coded constants. Unknown
    // values are null rather than plausible-but-wrong numbers.
    runtime_container_limits: resolveRuntimeContainerLimits(),
    generator_topology: {
      source_ip_count: preflight.source_ip_count,
      destination_tuple_capacity: preflight.destination_tuple_capacity,
      nginx_worker_processes: preflight.nginx_worker_processes,
      nginx_worker_connections: preflight.nginx_worker_connections,
      nginx_worker_fd_soft: preflight.nginx_worker_fd_soft,
      nginx_worker_fd_hard: preflight.nginx_worker_fd_hard,
      nginx_max_sse_capacity: preflight.nginx_max_sse_capacity,
      capacity_sufficient: preflight.capacity_sufficient,
      warnings: preflight.warnings,
      // §4.24: Enhanced capacity proof
      non_viewer_fds: preflight.non_viewer_fds,
      fd_headroom: preflight.fd_headroom,
      subscribers_per_nchan_node: preflight.subscribers_per_nchan_node,
      nchan_node_count: preflight.nchan_node_count,
      cpu_quota: preflight.cpu_quota,
      cpu_count: preflight.cpu_count,
      // §3.2: Multi-shard topology
      shard_count: preflight.shard_count,
      aggregate_target_connections: preflight.aggregate_target_connections,
      aggregate_destination_tuple_capacity: preflight.aggregate_destination_tuple_capacity,
      recommended_shard_count: preflight.recommended_shard_count,
      shard_capacity_each: preflight.shard_capacity_each,
      topology_note: preflight.topology_note,
    },
    scenario_active_concurrency: {
      lobby_subscribers: metrics.lobby_subscribers,
      match_001_subscribers: metrics.match_001_subscribers,
      match_002_subscribers: metrics.match_002_subscribers ?? 0,
      match_003_subscribers: metrics.match_003_subscribers ?? 0,
      match_004_subscribers: metrics.match_004_subscribers ?? 0,
      match_005_subscribers: metrics.match_005_subscribers ?? 0,
      match_006_subscribers: metrics.match_006_subscribers ?? 0,
      match_007_subscribers: metrics.match_007_subscribers ?? 0,
      match_008_subscribers: metrics.match_008_subscribers ?? 0,
      total_active_subscribers: (metrics.lobby_subscribers || 0)
        + (metrics.match_001_subscribers || 0)
        + (metrics.match_002_subscribers || 0)
        + (metrics.match_003_subscribers || 0)
        + (metrics.match_004_subscribers || 0)
        + (metrics.match_005_subscribers || 0)
        + (metrics.match_006_subscribers || 0)
        + (metrics.match_007_subscribers || 0)
        + (metrics.match_008_subscribers || 0),
    },
    scenario_results: verdictResult.checks.map((c) => ({
      name: c.name,
      passed: c.passed,
      detail: c.detail,
    })),
    structured_scenario_evidence: structuredScenarioEvidence ?? {},
    connection_metrics: {
      connections_attempted: metrics.connections_attempted,
      connections_established: metrics.connections_established,
      connection_failures: metrics.connection_failures,
      connections_dropped: metrics.connections_dropped,
      connections_target: metrics.connections_target,
      active_connections_peak: metrics.active_connections_peak ?? 0,
      // §4.17: Disconnect attribution
      deliberate_disconnects: metrics.deliberate_disconnects ?? 0,
      unexpected_client_disconnects: metrics.unexpected_client_disconnects ?? 0,
      server_initiated_disconnects: metrics.server_initiated_disconnects ?? 0,
      network_failures: metrics.network_failures ?? 0,
      shutdown_cleanup_disconnects: metrics.shutdown_cleanup_disconnects ?? 0,
    },
    event_metrics: {
      events_published: metrics.events_published,
      events_received: metrics.events_received,
      missing_sequences: metrics.missing_sequences,
      duplicates: metrics.duplicates,
      out_of_order: metrics.out_of_order,
    },
    live_delivery_accounting: {
      expected_fan_deliveries: metrics.expected_fan_deliveries,
      received_fan_deliveries: metrics.received_fan_deliveries,
      // §4.16: Live vs replay separation
      live_expected_deliveries: metrics.live_expected_deliveries,
      live_received_deliveries: metrics.live_received_deliveries,
      late_join_history_expected: metrics.late_join_history_expected,
      late_join_history_received: metrics.late_join_history_received,
      reconnect_replay_expected: metrics.reconnect_replay_expected,
      reconnect_replay_received: metrics.reconnect_replay_received,
      restart_replay_expected: metrics.restart_replay_expected,
      restart_replay_received: metrics.restart_replay_received,
    },
    latency_metrics: {
      fan_out_p50_ms: metrics.fan_out_latency_p50_ms,
      fan_out_p95_ms: metrics.fan_out_latency_p95_ms,
      fan_out_p99_ms: metrics.fan_out_latency_p99_ms,
      fan_out_max_ms: metrics.fan_out_latency_max_ms,
      late_join_p50_ms: metrics.late_join_p50_ms,
      late_join_p95_ms: metrics.late_join_p95_ms,
      late_join_p99_ms: metrics.late_join_p99_ms,
      late_join_max_ms: metrics.late_join_max_ms,
    },
    reconnect_metrics: {
      gaps: metrics.reconnect_gaps,
      duplicates: metrics.reconnect_duplicates,
      order_violations: metrics.reconnect_order_violations,
      expected: metrics.reconnect_replay_expected,
      received: metrics.reconnect_replay_received,
    },
    slow_client_metrics: {
      disconnects: metrics.slow_consumer_disconnects,
      non_slow_p95_degradation_pct: metrics.non_slow_p95_degradation_pct,
      // §4.7: Detailed slow-consumer metrics from scenario
      ...(metrics.slow_consumer_metrics ? {
        slow_clients: metrics.slow_consumer_metrics.slow_clients,
        healthy_clients: metrics.slow_consumer_metrics.healthy_clients,
        slow_offered_event_count: metrics.slow_consumer_metrics.slow_offered_event_count,
        slow_application_read_count: metrics.slow_consumer_metrics.slow_application_read_count,
        slow_backlog_growth: metrics.slow_consumer_metrics.slow_backlog_growth,
        backpressure_duration_ms: metrics.slow_consumer_metrics.backpressure_duration_ms,
        evidence_server_side_backpressure_reached: metrics.slow_consumer_metrics.evidence_server_side_backpressure_reached,
        healthy_p95_before_ms: metrics.slow_consumer_metrics.healthy_p95_before_ms,
        healthy_p95_during_slow_ms: metrics.slow_consumer_metrics.healthy_p95_during_slow_ms,
        healthy_degradation_pct: metrics.slow_consumer_metrics.healthy_degradation_pct,
        // §3.8: Per-client median intervals — each client should achieve ~2s pacing independently
        per_client_median_event_interval_ms: metrics.slow_consumer_metrics.per_client_median_event_interval_ms,
        // §3.8: Achieved read rate — proof of throttled consumption
        slow_achieved_read_rate_events_per_sec: metrics.slow_consumer_metrics.slow_achieved_read_rate_events_per_sec,
        slow_median_event_interval_ms: metrics.slow_consumer_metrics.slow_median_event_interval_ms,
        slow_p95_event_interval_ms: metrics.slow_consumer_metrics.slow_p95_event_interval_ms,
        // §3.8: Memory boundedness trend
        nchan_memory_bounded: metrics.slow_consumer_metrics.nchan_memory_bounded,
        nchan_memory_growth_bytes: metrics.slow_consumer_metrics.nchan_memory_growth_bytes,
        nchan_memory_growth_pct: metrics.slow_consumer_metrics.nchan_memory_growth_pct,
        // §M3-HVR: Last-Event-ID replay-probe evidence — retention measured at
        // the server, separated from post-window catch-up drain.
        pacing_valid: metrics.slow_consumer_metrics.pacing_valid,
        replay_probe_clients: metrics.slow_consumer_metrics.replay_probe_clients,
        replay_probe_selected: metrics.slow_consumer_metrics.replay_probe_selected,
        replay_probe_reattached: metrics.slow_consumer_metrics.replay_probe_reattached,
        replay_probe_expected_missed: metrics.slow_consumer_metrics.replay_probe_expected_missed,
        replay_probe_replayed: metrics.slow_consumer_metrics.replay_probe_replayed,
        replay_probe_coverage_pct: metrics.slow_consumer_metrics.replay_probe_coverage_pct,
        catchup_drained_count: metrics.slow_consumer_metrics.catchup_drained_count,
        replay_recovery_pct: metrics.slow_consumer_metrics.replay_recovery_pct,
      } : {}),
    },
    restart_metrics: {
      history_replay_correct: metrics.nchan_restart_history_replay_correct,
      missing_sequences: metrics.nchan_restart_missing_sequences,
      skipped: metrics.nchan_restart_skipped,
      // §3.9: Separated literal restart and cross-node replacement ranges
      literal_restart_expected: metrics.literal_restart_expected,
      literal_restart_received: metrics.literal_restart_received,
      cross_node_expected: metrics.cross_node_expected,
      cross_node_received: metrics.cross_node_received,
    },
    resource_metrics: {
      event_loop_delay_p99_ms: metrics.event_loop_delay_p99_ms,
      memory_mb_peak: metrics.memory_mb_peak,
      nchan_memory_mb_peak: metrics.nchan_memory_mb_peak,
      redis_memory_mb_peak: metrics.redis_memory_mb_peak,
      redis_memory_used_bytes: metrics.redis_memory_used_bytes ?? null,
      // §3.8.F: CPU percent fields — two units:
      //   *_cpu_percent_peak = raw percent of one CPU core (100% = 1 core fully utilized)
      //   *_resource_cpu_percent_peak = percent of assigned service capacity (normalized by cgroup limit)
      generator_cpu_percent_peak: metrics.generator_cpu_percent_peak,
      nchan_cpu_percent_peak: metrics.nchan_cpu_percent_peak,
      redis_cpu_percent_peak: metrics.redis_cpu_percent_peak,
      generator_event_loop_p99_ms: metrics.generator_event_loop_p99_ms,
      generator_backlog_peak: metrics.generator_backlog_peak,
      cpu_usage_usec: metrics.cpu_usage_usec,
      cpu_throttled_count: metrics.cpu_throttled_count,
      cpu_throttled_usec: metrics.cpu_throttled_usec,
      memory_oom_events: metrics.memory_oom_events,
      memory_oom_kill_events: metrics.memory_oom_kill_events,
      memory_current_bytes: metrics.memory_current_bytes,
      memory_peak_bytes: metrics.memory_peak_bytes,
      cpu_max_quota: metrics.cpu_max_quota,
      cpu_max_period: metrics.cpu_max_period,
      memory_max_bytes: metrics.memory_max_bytes,
      // §4.9: Nchan container resource metrics
      nchan_cpu_usage_usec: metrics.nchan_cpu_usage_usec,
      nchan_cpu_throttled_count: metrics.nchan_cpu_throttled_count,
      nchan_cpu_throttled_usec: metrics.nchan_cpu_throttled_usec,
      nchan_memory_current_bytes: metrics.nchan_memory_current_bytes,
      // §3.8.D: Note: memory.peak is container-lifetime, not per-run. Cannot be reset via control server.
      nchan_memory_peak_bytes: metrics.nchan_memory_peak_bytes,
      nchan_memory_container_lifetime_peak_bytes: metrics.nchan_memory_container_lifetime_peak_bytes ?? null,
      nchan_memory_oom_events: metrics.nchan_memory_oom_events,
      nchan_memory_oom_kill_events: metrics.nchan_memory_oom_kill_events,
      // §4.9: Redis connected-client peak
      redis_connected_clients_peak: metrics.redis_connected_clients_peak,
      // §3.8.F: Normalized CPU percent (each service's own denominator)
      resource_cpu_percent_peak: metrics.resource_cpu_percent_peak,
      nchan_resource_cpu_percent_peak: metrics.nchan_resource_cpu_percent_peak,
      redis_resource_cpu_percent_peak: metrics.redis_resource_cpu_percent_peak,
      resource_cpu_baseline: metrics.resource_cpu_baseline,
    },
    publisher_metrics: {
      attempts: metrics.publisher_attempts,
      successes: metrics.publisher_successes,
      definite_failures: metrics.publisher_definite_failures,
      ambiguous_failures: metrics.publisher_ambiguous_failures,
    },
    parse_error_metrics: {
      sse_parse_errors: metrics.sse_parse_errors,
      json_parse_errors: metrics.json_parse_errors,
      invalid_timestamp_count: metrics.invalid_timestamp_count,
      // §4.19: Schema validation error accounting
      schema_validation_errors: metrics.schema_validation_errors,
      missing_transport_id: metrics.missing_transport_id,
    },
    surge_health: {
      fan_out_p95_ms: metrics.surge_fan_out_p95_ms,
      missing_sequences: metrics.surge_missing_sequences,
      duplicates: metrics.surge_duplicates,
      out_of_order: metrics.surge_out_of_order,
      events_received: metrics.surge_events_received,
      // §4.5: Surge timing metrics
      surge_target_additions: metrics.surge_target_additions,
      surge_attempted: metrics.surge_attempted,
      surge_established: metrics.surge_established,
      surge_failures: metrics.surge_failures,
      surge_start_time: metrics.surge_start_time,
      surge_end_time: metrics.surge_end_time,
      surge_elapsed_ms: metrics.surge_elapsed_ms,
      surge_timing_error_ms: metrics.surge_timing_error_ms,
      attempt_rate_peak: metrics.attempt_rate_peak,
      establishment_rate_peak: metrics.establishment_rate_peak,
      scheduler_lag_p95: metrics.scheduler_lag_p95,
      scheduler_lag_max: metrics.scheduler_lag_max,
      active_population_start: metrics.active_population_start,
      active_population_end: metrics.active_population_end,
      active_population_peak: metrics.active_population_peak,
    },
    // §3.15: Per-scenario active concurrency for reconnect
    reconnect_health: {
      active_start: metrics.reconnect_active_start,
      active_peak: metrics.reconnect_active_peak,
      active_end: metrics.reconnect_active_end,
    },
    // §3.11.C: Per-scenario active concurrency for other peak-load scenarios
    late_join_active_population: {
      start: metrics.late_join_active_start,
      peak: metrics.late_join_active_peak,
      end: metrics.late_join_active_end,
    },
    burst_active_population: {
      start: metrics.burst_active_start,
      peak: metrics.burst_active_peak,
      end: metrics.burst_active_end,
    },
    slow_consumer_active_population: {
      start: metrics.slow_consumer_active_start,
      peak: metrics.slow_consumer_active_peak,
      end: metrics.slow_consumer_active_end,
    },
    restart_active_population: {
      start: metrics.restart_active_start,
      peak: metrics.restart_active_peak,
      end: metrics.restart_active_end,
    },
    phase_publish_rates: metrics.phase_publish_rates,
    // §4.18: Workload rate metrics with separate match/lobby/total rates
    workload_rate_metrics: {
      total_events_per_sec: metrics.total_events_per_sec,
      match_events_per_sec: metrics.match_events_per_sec,
      lobby_events_per_sec: metrics.lobby_events_per_sec,
      match_events_published: metrics.match_events_published,
      lobby_events_published: metrics.lobby_events_published,
      // §3.7: Attempted vs accepted counts
      match_events_attempted: metrics.match_events_attempted,
      lobby_events_attempted: metrics.lobby_events_attempted,
      total_events_attempted: metrics.match_events_attempted + metrics.lobby_events_attempted,
      total_events_accepted: metrics.match_events_published + metrics.lobby_events_published,
      phase_rates: metrics.phase_publish_rates,
    },
    // §4.18: Scheduler lag metrics (separate from surge health)
    scheduler_lag_metrics: {
      p95_ms: metrics.scheduler_lag_p95,
      max_ms: metrics.scheduler_lag_max,
    },
    // §4.18: Connection establishment rate metrics
    connection_establishment_rate_metrics: {
      attempt_rate_peak: metrics.attempt_rate_peak,
      establishment_rate_peak: metrics.establishment_rate_peak,
    },
    // §4.18: Disconnect attribution (separate section for machine-readable)
    disconnect_attribution: {
      deliberate_disconnects: metrics.deliberate_disconnects ?? 0,
      unexpected_client_disconnects: metrics.unexpected_client_disconnects ?? 0,
      server_initiated_disconnects: metrics.server_initiated_disconnects ?? 0,
      network_failures: metrics.network_failures ?? 0,
      shutdown_cleanup_disconnects: metrics.shutdown_cleanup_disconnects ?? 0,
    },
    // §4.18: Late-join metrics (separate structured section)
    late_join_metrics: {
      p50_ms: metrics.late_join_p50_ms,
      p95_ms: metrics.late_join_p95_ms,
      p99_ms: metrics.late_join_p99_ms,
      max_ms: metrics.late_join_max_ms,
      history_expected: metrics.late_join_history_expected,
      history_received: metrics.late_join_history_received,
      history_missing: (metrics.late_join_history_expected ?? 0) - (metrics.late_join_history_received ?? 0),
    },
    viewer_concentration: {
      lobby_subscribers: metrics.lobby_subscribers,
      match_001_subscribers: metrics.match_001_subscribers,
      match_002_subscribers: metrics.match_002_subscribers ?? 0,
      match_003_subscribers: metrics.match_003_subscribers ?? 0,
      match_004_subscribers: metrics.match_004_subscribers ?? 0,
      match_005_subscribers: metrics.match_005_subscribers ?? 0,
      match_006_subscribers: metrics.match_006_subscribers ?? 0,
      match_007_subscribers: metrics.match_007_subscribers ?? 0,
      match_008_subscribers: metrics.match_008_subscribers ?? 0,
      total_active_subscribers: (metrics.lobby_subscribers || 0)
        + (metrics.match_001_subscribers || 0)
        + (metrics.match_002_subscribers || 0)
        + (metrics.match_003_subscribers || 0)
        + (metrics.match_004_subscribers || 0)
        + (metrics.match_005_subscribers || 0)
        + (metrics.match_006_subscribers || 0)
        + (metrics.match_007_subscribers || 0)
        + (metrics.match_008_subscribers || 0),
    },
    validity: {
      timing_valid: metrics.timing_valid,
      generator_healthy: generatorHealthy,
      // §4.18: Structured validity reasons from failed inconclusive checks
      reasons: verdictResult.checks
        .filter((c) => c.name.startsWith("inconclusive_override") && !c.passed)
        .map((c) => c.detail),
    },
    // §4.18: Measurement validity — conditions that could invalidate measurement
    measurement_validity: {
      timing_valid: metrics.timing_valid,
      generator_healthy: generatorHealthy,
      topology_capacity_sufficient: metrics.topology_capacity_sufficient,
      no_schema_errors: (metrics.schema_validation_errors + metrics.missing_transport_id) === 0,
      no_parse_errors: (metrics.sse_parse_errors + metrics.json_parse_errors) === 0,
    },
    // §4.25: Histogram sample populations and overflow
    histogram_populations: {
      fan_out: {
        sample_count: metrics.fan_out_sample_count,
        overflow_count: metrics.fan_out_overflow_count,
      },
      late_join: {
        sample_count: metrics.late_join_sample_count,
        overflow_count: metrics.late_join_overflow_count,
      },
    },
    // §4.25: Per-phase latency histograms — each phase has isolated fan-out and late-join percentiles
    phase_latency_histograms: metrics.phase_histograms,
    // §4.15/§4.18: Clock validity — propagate the actual measured/proven clock-validity object.
    // The evidence suite and single-run path both produce this from real Nchan reachability checks.
    // Never substitute a hardcoded placeholder — always use the measured result.
    clock_validity: metrics.clock_validity ?? {
      clock_model: "unknown",
      nodes_covered: [],
      measurement_method: "unknown",
      offset_or_guarantee: 0,
      uncertainty_ms: 0,
      threshold_ms: 0,
      validity_result: "INCONCLUSIVE" as const,
      nchan1_reachable: false,
      nchan2_reachable: false,
    },
    // §4.18/§3.15: Claim provenance — distinguish POC measurement from production inference
    claim_provenance: {
      measured_at_scale: config.targetConnections,
      // §3.15: Direct-accept requires ALL:
      // - configured 100k target
      // - actual active peak >= configured target (must have physically reached it)
      // - topology capacity sufficient
      // - generator healthy (CPU < 90%, event-loop < 100ms)
      // - timing valid
      // - events actually published and received
      // §3.8.E: Campaign-level target for multi-shard 100k campaigns
      direct_accept_eligible: config.runMode !== "coordinated-shard" && ((config.targetConnections * (parseInt(process.env.SHARD_TOTAL ?? process.env.SHARD_COUNT ?? "1", 10) || 1)) >= 100000)
        && (metrics.active_connections_peak ?? 0) >= (config.targetConnections * (parseInt(process.env.SHARD_TOTAL ?? process.env.SHARD_COUNT ?? "1", 10) || 1))
        && preflight.capacity_sufficient
        && metrics.generator_cpu_percent_peak < 90
        && metrics.generator_event_loop_p99_ms < 100
        && metrics.timing_valid
        && metrics.events_published > 0
        && metrics.events_received > 0,
      production_inference_only: config.targetConnections < 100000
        || (metrics.active_connections_peak ?? 0) < (config.targetConnections * (parseInt(process.env.SHARD_TOTAL ?? process.env.SHARD_COUNT ?? "1", 10) || 1))
        || !preflight.capacity_sufficient
        || metrics.generator_cpu_percent_peak >= 90
        || metrics.generator_event_loop_p99_ms >= 100
        || !metrics.timing_valid
        || metrics.events_published === 0
        || metrics.events_received === 0,
      note: config.targetConnections >= 100000
        ? "Direct local measurement at 100k target"
        : "Lower-scale result — production inference only, not direct 100k proof",
    },
    // §4.18: Frozen viewer model
    viewer_model: {
      viewer_count: config.targetConnections,
      sse_connection_count: config.targetConnections,
      connections_per_viewer: 1,
      note: "1 SSE connection per viewer (anonymous read-only)",
    },
    classification: {
      verdict: verdictResult.verdict,
      checks: verdictResult.checks,
    },
    // §4.22: Build identity — exact upstream versions and commit
    build_identity: metrics.build_identity,
    // §3.15: Campaign provenance — distinguishes per-run from campaign aggregate
    aggregate_type: metrics.aggregate_type ?? "single_run",
    run_count: metrics.run_count ?? 1,
  }

  // Emit as a single JSON line on stdout for machine parsing
  console.log(JSON.stringify(result))
}
